package org.example;

public class Pregunta {
    private String enunciado;
    private Categoria categoria;
    private Dificultad dificultad;
    private TipoPregunta tipoPregunta;

    public Pregunta(String enunciado, Categoria categoria, Dificultad dificultad, TipoPregunta tipoPregunta) {
        this.enunciado = enunciado;
        this.categoria = categoria;
        this.dificultad = dificultad;
        this.tipoPregunta = tipoPregunta;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    public TipoPregunta getTipoPregunta() {
        return tipoPregunta;
    }

    public void setTipoPregunta(TipoPregunta tipoPregunta) {
        this.tipoPregunta = tipoPregunta;
    }

    @Override
    public String toString() {
        return "Pregunta{" +
                "enunciado='" + enunciado + '\'' +
                ", categoria=" + categoria +
                ", dificultad=" + dificultad +
                ", tipoPregunta=" + tipoPregunta +
                '}';
    }
}
