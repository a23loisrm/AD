package org.example;

public class PreguntaTrueFalse extends Pregunta {
    private boolean respuesta;

    public PreguntaTrueFalse(String enunciado, Categoria categoria, Dificultad dificultad, TipoPregunta tipoPregunta, boolean respuesta) {
        super(enunciado, categoria, dificultad, tipoPregunta);
        this.respuesta = respuesta;
    }

    public boolean isRespuesta() {
        return respuesta;
    }

    public void setRespuesta(boolean respuesta) {
        this.respuesta = respuesta;
    }

    @Override
    public String toString() {
        return "PreguntaTrueFalse{" +
                "respuesta=" + respuesta +
                '}';
    }
}
