package org.example;

public enum TipoPregunta {
    MULTIPLE_CHOICE, TRUE_FALSE;
}
